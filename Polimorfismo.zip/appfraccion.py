from fraccion import Fraccion 

a = Fraccion(1,2)
b = Fraccion(3,4)
print("a =", a)
print("b =", b)
c = a + b
print("c =", c)
d = a - b
print("d =", d)
    
    

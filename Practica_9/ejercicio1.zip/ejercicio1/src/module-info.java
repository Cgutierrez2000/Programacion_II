/**
 * 
 */
/**
 * 
 */
module Practica_9 {
	requires java.desktop;
}